import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'my-app1';

}

  //name;
  
 // l;
  
 
//   fp(){
  
//   if(this.name.length>=0 && this.name.length<=4)
  
//     this.l=4;
  
//     if(this.name.length>4&&this.name.length<=8)
  
//     this.l=8;
  
//   }
// }
